function pvFarmDraw(x,y,tableW,tableH,quadRows,quadCols,modW,modH,tableRows,tableCols,numCB)
if numCB ~= 0
    quadH = quadRows*tableH + 10;
    quadW = quadCols*tableW + 10;

    pvQuadDraw(x,y,tableW,tableH,quadRows,quadCols,modW,modH,tableRows,tableCols,0)
    pvQuadDraw(x,y + quadH,tableW,tableH,quadRows,quadCols,modW,modH,tableRows,tableCols,0)
    pvQuadDraw(x + quadW,y,tableW,tableH,quadRows,quadCols,modW,modH,tableRows,tableCols,1)
    pvQuadDraw(x + quadW,y + quadH,tableW,tableH,quadRows,quadCols,modW,modH,tableRows,tableCols,1)

    ylabel('Meters');
    xlabel('Meters');
    numTables = quadRows * quadCols * 4;

    title1 = horzcat('Quads are ',num2str(quadCols),' tables wide by ',num2str(quadRows),' tables tall.');
    title2 = horzcat(num2str(numTables),' tables total, with ',num2str(numCB),' combiner boxes.');
    title({title1,title2});
else
    quadH = quadRows*tableH + 10;
    quadW = quadCols*tableW + 10;

    pvQuadDraw(x,y,tableW,tableH,quadRows,quadCols,modW,modH,tableRows,tableCols,0)
    pvQuadDraw(x,y + quadH,tableW,tableH,quadRows,quadCols,modW,modH,tableRows,tableCols,0)
    pvQuadDraw(x + quadW,y,tableW,tableH,quadRows,quadCols,modW,modH,tableRows,tableCols,0)
    pvQuadDraw(x + quadW,y + quadH,tableW,tableH,quadRows,quadCols,modW,modH,tableRows,tableCols,0)

    ylabel('Meters');
    xlabel('Meters');
    numTables = quadRows * quadCols * 4;

    title1 = horzcat('Quads are ',num2str(quadCols),' tables wide by ',num2str(quadRows),' tables tall.');
    title2 = horzcat(num2str(numTables),' tables total.');
    title({title1,title2});
end