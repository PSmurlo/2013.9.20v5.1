function [suml,maxl,l,qHleft] = aluminumRuns(numCB,qH,totH,array2inverter)

l = 0;
% z = qH / numCB;
n = 1;

% if mod(z,1) == 0 %if the CBs are all fully utilized
%     for i = 0:z:(qH-z)
%         l(n) = (i*totH+array2inverter)*2;
%         n = n + 1;
%     end
% else % if the CBs are not all fully utilized
%     % The non-fully utilized CB will be closest to the inverter
%     qHeven = (floor(z) * numCB);
%     qHleft = qH - qHeven;
%     for i = 0:z:(qH-floor(z))
%         l(n) = ((i+qHleft)*totH + array2inverter)*2;
%         n = n + 1;
%     end
% end

for qHleft=0:numCB
    if(mod((qH-qHleft)/numCB,1)==0)
        z=(qH-qHleft)/numCB;
        break
    end
end
for i = 0:z:(qH-qHleft-z)
    l(n) = ((i+qHleft)*totH + array2inverter)*2;
    n = n + 1;
end

l=l/2;
maxl=max(l)/2;
suml=sum(l);


