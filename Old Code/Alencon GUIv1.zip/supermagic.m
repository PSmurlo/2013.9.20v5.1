function y = supermagic(x)

y = x*5 + 3;