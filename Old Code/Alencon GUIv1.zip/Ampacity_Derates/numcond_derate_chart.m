function [percent]=numcond_derate_chart(num_cond)
    if(num_cond<3)
        percent=1;
    elseif(num_cond<=6)
        percent=.80;
    elseif(num_cond<=9)
        percent=.70;
    elseif(num_cond<=20)
        percent=.50;
    elseif(num_cond<=30)
        percent=.45;
    elseif(num_cond<=40)
        percent=.40;
    elseif(num_cond>40)  
        percent=.35;
    end

    
        