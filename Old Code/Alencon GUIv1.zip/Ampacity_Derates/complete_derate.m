function [derated_ampacity, table] =complete_derate(Ta,Tc,chart,OCPD,cond_per_run)
[table,tTa] = table310_select(chart);
temp_derate = temp_derate_formula(Ta,tTa,Tc);
numcond_derate=numcond_derate_chart(cond_per_run);
derated_ampacity=OCPD/(temp_derate*numcond_derate);