function [min_index]=table310_size(table,type,Tc,deratedAmpacity)%310.15(B)(20) 2011 NEC
num_sizes=30;

if (or(strcmp('Cu',type),type)==1)
    if(Tc ==75)
        row=1;
    elseif(Tc == 90)
        row=2;
    end
    
elseif(or(strcmp('Al',type),type)==0)
    if(Tc == 75)
        row=3;
    elseif(Tc == 90)
        row=4;
    end
end
if(table(row,30)<deratedAmpacity)
    min_index=31;
%     disp('Current too large');
    return
else
    for i=1:num_sizes
        if(table(row,i)>=deratedAmpacity)
            min_index=i;
            break
        end
    end
end

% if(exist('min_index','var')==0)
%     disp('too much current')
%     size_short{1}='N/A';
%     lookup_values=0;
%     return
% end
% deratedAmpacity_values=zeros(1,num_sizes-min_index);
% 
% for j=1:(num_sizes-min_index)
%     size_index(j)=min_index-1+j;
%     lookup_values(j)=table(row,(min_index-1+j));
% end



