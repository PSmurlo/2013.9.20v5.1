function [derate]=temp_derate_formula(table_ambient,actual_ambient,conductor_temp) %310.15(B)(2)
derate=sqrt((conductor_temp-actual_ambient)/(conductor_temp-table_ambient));