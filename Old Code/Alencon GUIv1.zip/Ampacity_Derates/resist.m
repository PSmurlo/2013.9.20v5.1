%Program calculates Rdc

%L = length (ohm/km)
%Tc = Conductor rating
%type = type of conductor ('Al' or 'Cu') or 1 or 0 respectively
%awg must be a string or index of the vector of strings


% 0 is Au, 1 is Cu

function [Rdc] = resist(Tc,type,index)
load('resistance.mat');
acu = 0.00323; %alpha of Cu
aal = 0.0033;  %alpha of Al

if nargin < 3
    %Check what material we're working with:
    if(or(strcmp('Al',type),type==0))
        a = aal; %alpha
        res=Aluminum;
    elseif(or(strcmp('Cu',type),type==1))
        a = acu;
        res=Copper;
    else
        disp('invalid input');
    end
    %end material check
    
else
    %Check what material we're working with:
    if(or(strcmp('Al',type),type==0))
        a = aal; %alpha
        res=Aluminum(index);
    elseif(or(strcmp('Cu',type),type==1))
        a = acu;
        res=Copper(index);
    else
        disp('invalid input');
    end
    %end material check
end
a_res = res*(1 + a*(Tc-75)); %adjusted ohms per km
Rdc = a_res;
%oldcode

% if(rem(awg,1)==0 && awg>0 && awg <=30)
%     opk1=Copper(awg);
%     opk2=Aluminum(awg);
% elseif(rem(awg,1)==0)
%     disp('resist invalid wire');
% else
%     for i=1:length(sizes)
%         if(strcmp(awg,sizes{i})==1)
%             opk1=Copper(i);
%             opk2=Aluminum(i);
%             break
%         end
%     end
% end