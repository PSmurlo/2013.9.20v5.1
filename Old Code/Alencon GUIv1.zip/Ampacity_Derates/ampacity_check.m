function [min_index,Rdc]=ampacity_check(Ta,Tc,type,table_identity,OCPD,cond_per_raceway)
[deratedAmpacity,table] =complete_derate(Ta,Tc,table_identity,OCPD,cond_per_raceway);
[min_index] = table310_size(table,type,Tc,deratedAmpacity);
Rdc = resist(Tc,type);