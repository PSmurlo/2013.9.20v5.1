function [wire_index]=get_index(string)%searches vector for char or int
sizes=cellstr(['18  ';'16  ';'14  ';'12  ';'10  ';'8   ';'6   ';'4   ';'3   ';'2   ';'1   ';'1/0 ';'2/0 ';'3/0 ';'4/0 ';'250 ';'300 ';'350 ';'400 ';'500 ';'600 ';'700 ';'750 ';'800 ';'900 ';'1000';'1250';'1500';'1750';'2000']); 
numsizes=length(sizes);
for i=1:numsizes
    if(strcmp(string,sizes{i})==1)
        wire_index=i;
    end
end
if(isdef(wire_index==0))
    disp('undefined wire size');
end

