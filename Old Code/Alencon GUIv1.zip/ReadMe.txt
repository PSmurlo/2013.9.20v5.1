GUIv2.m -- MATLAB GUIDE

Alencon Conductor and BoS Optimization Notes

1. Move sliders to change prices for specific inputs

2. Wire pricing held in "wirePriceFt.mat"

3. Must stop the Auto-updater to look at specific points on graph

4. Toggle "Alencon/Conventional" button to change between array topologies


GUIv3 planned changes (Monday/Tuesday meeting with Alencon)

1. Overlay of Conventional and Alencon Graphs

2. Display of selected points shown for both Alencon and Conventional

3. Price of GrIP not included in Alencon data, to be included
