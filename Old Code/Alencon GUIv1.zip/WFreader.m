function [WF]=WFreader(data)

% Create the wfreader module and run it
module = ssccall('module_create', 'wfreader');
ssccall('module_exec', module, data);

% Get wind direction data
WF.wdir=ssccall('data_get_array',data,'wdir');
WF.tdry = ssccall('data_get_array', data, 'hourly_ambtemp');
WF.wspd = ssccall('data_get_array', data, 'hourly_windspd');
WF.sun_zen = ssccall('data_get_array', data, 'hourly_sol_zen');
WF.incidence = ssccall('data_get_array', data, 'hourly_sol_alt');
WF.surf_tilt = ssccall('data_get_array', data, 'hourly_subarray1_surf_tilt');
WF.site_elevation = ssccall('data_get_number', data, 'elev');