function [VD,VD_percent]= voltdrop(length,resistance,Imp,Vmaxpower)
%takes the resistance, current at max power, 
% threephase*.866 %assuming 100 percent pf
VD= ((2*length*Imp).*resistance) / 1000; %OHMS/KM TO OHMS/M
VD_percent= (VD./Vmaxpower)*100;