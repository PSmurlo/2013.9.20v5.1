function [VD, VDPercent] = spotVoltDrop(length,resistance,ImpSpot,Vmaxpower,rows)

VD=0;                 % Initalize total volt drop to zero
VDPercent=0;      % Initalize total VD percent to zero

% Loop to calculate VD as current builds up along branch run
for i=2:2:rows*2
    
    % Calculates to volt drop for given current 
    voltage_drop=(2*length*resistance*ImpSpot*i)/1000;
    VD_percent=(voltage_drop/Vmaxpower)*100;
    
    % Updates the total VD and VD% of system 
    VD = VD + voltage_drop;
    VDPercent = VDPercent + VD_percent;
end
