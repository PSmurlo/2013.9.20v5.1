function [lt,maxStringRun1d] = stringRuns(qW,qH,totW,totH,numCB,modality,CBqH)

if modality == 0; % portrait
    l1 = totW*qW*4; %4 runs, first and second length
    % first length is behind modules
    l2 = sum(0:1/2:qW)*totW *4;
    %second length is from modules to end of quad
    lt = l1 + l2;
else % landscape
     l1 = totW*qW*8; %8 runs
     % first length is behind modules
     l2 = sum(0:1:qW)*8*totW;
     %second length is from modules to end of quad
     lt = l1 + l2;
end

h1 = 5; %misc distances from end of quad to cable tray
h2 = sum(0:CBqH)*totH; %distance from cable tray to combiner box
ht =(h1+h2)*qW*8; %number of conductors per table

lt =(ht * numCB)...   % North South
    + (lt * qH);      % East West
%Per quad

maxStringRun1d = (qW * totW)...% East West
    + h1 + CBqH*totH; % North South

%     for i = 1:qW
%         stringLength = stringLength + 2*totW ... %2 lengths of conductor
%         *i*4; %i is number of tables 4 strings per table
%     % total length of west-east wire
%     end